package com.tis.service;

import org.springframework.stereotype.Service;

@Service
public interface NewsService {

}
