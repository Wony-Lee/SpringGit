package com.tis.domain;

import lombok.Data;

@Data
public class NewsVO {

}
